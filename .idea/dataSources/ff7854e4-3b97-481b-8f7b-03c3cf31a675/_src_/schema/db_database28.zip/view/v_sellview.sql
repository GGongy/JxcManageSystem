CREATE VIEW v_sellview AS
  SELECT
    `db_database28`.`tb_sell_main`.`sellID`                                         AS `sellID`,
    `db_database28`.`tb_spinfo`.`spname`                                            AS `spname`,
    `db_database28`.`tb_sell_detail`.`spid`                                         AS `spid`,
    `db_database28`.`tb_spinfo`.`gg`                                                AS `gg`,
    `db_database28`.`tb_sell_detail`.`dj`                                           AS `dj`,
    `db_database28`.`tb_sell_detail`.`sl`                                           AS `sl`,
    (`db_database28`.`tb_sell_detail`.`sl` * `db_database28`.`tb_sell_detail`.`dj`) AS `je`,
    `db_database28`.`tb_sell_main`.`khname`                                         AS `khname`,
    `db_database28`.`tb_sell_main`.`xsdate`                                         AS `xsdate`,
    `db_database28`.`tb_sell_main`.`czy`                                            AS `czy`,
    `db_database28`.`tb_sell_main`.`jsr`                                            AS `jsr`,
    `db_database28`.`tb_sell_main`.`jsfs`                                           AS `jsfs`
  FROM ((`db_database28`.`tb_sell_detail`
    JOIN `db_database28`.`tb_sell_main`
      ON ((`db_database28`.`tb_sell_detail`.`sellID` = `db_database28`.`tb_sell_main`.`sellID`))) JOIN
    `db_database28`.`tb_spinfo` ON ((`db_database28`.`tb_sell_detail`.`spid` = `db_database28`.`tb_spinfo`.`id`)));
