CREATE VIEW v_rukuview AS
  SELECT
    `db_database28`.`tb_ruku_main`.`rkID`                                           AS `rkID`,
    `db_database28`.`tb_ruku_detail`.`spid`                                         AS `spid`,
    `db_database28`.`tb_spinfo`.`spname`                                            AS `spname`,
    `db_database28`.`tb_spinfo`.`gg`                                                AS `gg`,
    `db_database28`.`tb_ruku_detail`.`dj`                                           AS `dj`,
    `db_database28`.`tb_ruku_detail`.`sl`                                           AS `sl`,
    (`db_database28`.`tb_ruku_detail`.`dj` * `db_database28`.`tb_ruku_detail`.`sl`) AS `je`,
    `db_database28`.`tb_spinfo`.`gysname`                                           AS `gysname`,
    `db_database28`.`tb_ruku_main`.`rkdate`                                         AS `rkdate`,
    `db_database28`.`tb_ruku_main`.`czy`                                            AS `czy`,
    `db_database28`.`tb_ruku_main`.`jsr`                                            AS `jsr`,
    `db_database28`.`tb_ruku_main`.`jsfs`                                           AS `jsfs`
  FROM ((`db_database28`.`tb_ruku_detail`
    JOIN `db_database28`.`tb_ruku_main`
      ON ((`db_database28`.`tb_ruku_detail`.`rkID` = `db_database28`.`tb_ruku_main`.`rkID`))) JOIN
    `db_database28`.`tb_spinfo` ON ((`db_database28`.`tb_ruku_detail`.`spid` = `db_database28`.`tb_spinfo`.`id`)));
